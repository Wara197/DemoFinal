// เซิร์ฟเวอร์ Express สำหรับระบบสั่งอาหารออนไลน์ (npm start)
const path = require("path");
const express = require("express");
const jwt = require("jsonwebtoken");
const { pool } = require("./db");
const { port, jwtSecret, staff } = require("./config");

const app = express();

// แปลง body ที่เป็น JSON ให้อยู่ใน req.body
app.use(express.json());

// ให้บริการไฟล์ในโฟลเดอร์ public เช่น index.html (ลูกค้า) และ kitchen.html (ร้านค้า)
app.use(express.static(path.join(__dirname, "public")));

// สถานะที่อนุญาตของออเดอร์
const ORDER_STATUSES = ["pending", "preparing", "delivered", "cancelled"];
// สถานะสุดท้าย เปลี่ยนต่อไม่ได้แล้ว
const FINAL_STATUSES = ["delivered", "cancelled"];
// หมวดหมู่ของเมนู
const MENU_CATEGORIES = ["อาหาร", "เครื่องดื่ม", "ของหวาน"];

// ---------- ฟังก์ชันช่วยเหลือ ----------

// ตรวจว่าเป็นจำนวนเต็มบวก (ใช้กับ id และ quantity)
const isPositiveInt = (value) => Number.isInteger(value) && value > 0;

// ข้อความที่ไม่บังคับ (เช่น หมายเหตุ) คืน null ถ้าว่าง, คืน undefined ถ้ารูปแบบผิด
const cleanOptional = (value, max) => {
  if (value === undefined || value === null || value === "") return null;
  if (typeof value !== "string" || value.trim().length > max) return undefined;
  return value.trim() === "" ? null : value.trim();
};

// แปลงแถวจากฐานข้อมูลให้เป็นรูปแบบที่ส่งให้ผู้ใช้
// mysql2 ส่ง DECIMAL มาเป็น string และ BOOLEAN เป็น 0/1 จึงต้องแปลงก่อน
const toMenuItem = (row) => ({
  id: row.id,
  name: row.name,
  category: row.category,
  price: Number(row.price),
  available: Boolean(row.available),
});

// ตอบ 500 เมื่อเกิดข้อผิดพลาดกับฐานข้อมูล และบันทึก log ไว้ในเซิร์ฟเวอร์
const sendServerError = (res, err, message) => {
  console.error(message, err.message);
  res.status(500).json({ error: message });
};

// ตรวจข้อมูลเมนู ใช้ทั้งตอนเพิ่ม (POST) และแก้ไข (PUT)
// categoryRequired = true ตอนเพิ่มเมนูใหม่ ส่วนตอนแก้ไขจะไม่ส่งหมวดหมู่มาก็ได้
// คืนข้อความ error ถ้าข้อมูลผิด หรือ null ถ้าถูกต้อง
function checkMenuBody(body, categoryRequired) {
  const { name, price, available, category } = body;

  if (typeof name !== "string" || name.trim() === "" || name.trim().length > 200) {
    return "name ต้องเป็นข้อความ 1-200 ตัวอักษร";
  }
  // ราคาเป็นตัวเลข ไม่ติดลบ ไม่เกิน 99999999.99 และทศนิยมไม่เกิน 2 ตำแหน่ง (ตรงกับ DECIMAL(10,2))
  if (
    typeof price !== "number" ||
    !Number.isFinite(price) ||
    price < 0 ||
    price > 99999999.99 ||
    Math.round(price * 100) !== price * 100
  ) {
    return "price ต้องเป็นตัวเลขไม่ติดลบ ทศนิยมไม่เกิน 2 ตำแหน่ง";
  }
  if (typeof available !== "boolean") {
    return "available ต้องเป็น true หรือ false";
  }
  if (categoryRequired || category !== undefined) {
    if (!MENU_CATEGORIES.includes(category)) {
      return `category ต้องเป็นหนึ่งใน: ${MENU_CATEGORIES.join(", ")}`;
    }
  }
  return null;
}

// ตรวจ token ของพนักงานร้าน (ต้องส่ง header: Authorization: Bearer <token>)
// ใช้ครอบ endpoint ที่ลูกค้าเรียกไม่ได้ เช่น เปลี่ยนสถานะ แก้เมนู ดูออเดอร์ทั้งหมด
function requireStaff(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  try {
    const payload = jwt.verify(token, jwtSecret);
    if (payload.role !== "staff") throw new Error("ไม่ใช่พนักงาน");
    req.user = payload;
    next();
  } catch (err) {
    res.status(401).json({ error: "ต้องเข้าสู่ระบบด้วยบัญชีพนักงานก่อน" });
  }
}

// ดึงรายละเอียดออเดอร์ 1 รายการ พร้อมรายการอาหารและยอดรวม
// คืนค่า null ถ้าไม่พบออเดอร์
async function getOrderDetail(orderId) {
  const [orders] = await pool.query(
    "SELECT id, customer_name, status, delivery_info, created_at FROM orders WHERE id = ?",
    [orderId]
  );
  if (orders.length === 0) return null;

  // JOIN กับ menu_items เพื่อเอาชื่อและราคา แล้วคำนวณยอดของแต่ละรายการ
  const [items] = await pool.query(
    `SELECT oi.menu_item_id, m.name, m.price, oi.quantity, oi.note,
            (m.price * oi.quantity) AS subtotal
       FROM order_items oi
       JOIN menu_items m ON m.id = oi.menu_item_id
      WHERE oi.order_id = ?
      ORDER BY oi.id`,
    [orderId]
  );

  const detailItems = items.map((item) => ({
    menu_item_id: item.menu_item_id,
    name: item.name,
    price: Number(item.price),
    quantity: item.quantity,
    note: item.note,
    subtotal: Number(item.subtotal),
  }));

  // รวมยอดทั้งออเดอร์ และปัดทศนิยมให้เหลือ 2 ตำแหน่ง
  const total = detailItems.reduce((sum, item) => sum + item.subtotal, 0);

  return {
    id: orders[0].id,
    customer_name: orders[0].customer_name,
    status: orders[0].status,
    delivery_info: orders[0].delivery_info,
    created_at: orders[0].created_at,
    items: detailItems,
    total: Math.round(total * 100) / 100,
  };
}

// ---------- Endpoint: เข้าสู่ระบบพนักงาน ----------

// POST /api/auth/login : รับ { "username", "password" } แล้วคืน JWT (อายุ 8 ชั่วโมง)
app.post("/api/auth/login", (req, res) => {
  const { username, password } = req.body || {};
  if (typeof username !== "string" || typeof password !== "string" || !username || !password) {
    return res.status(400).json({ error: "ต้องส่ง username และ password" });
  }
  if (username !== staff.username || password !== staff.password) {
    return res.status(401).json({ error: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" });
  }

  const token = jwt.sign({ role: "staff", sub: username }, jwtSecret, { expiresIn: "8h" });
  res.json({ token, user: { username, role: "staff" } });
});

// ---------- Endpoint: เมนู ----------

// GET /api/menu : ดูเมนู
// ตัวกรองที่ใช้ได้: ?available=1 (เฉพาะที่พร้อมขาย), ?category=อาหาร, ?q=กุ้ง (ค้นหาจากชื่อ)
app.get("/api/menu", async (req, res) => {
  const { available, category, q } = req.query;
  if (category !== undefined && !MENU_CATEGORIES.includes(category)) {
    return res.status(400).json({ error: `category ต้องเป็นหนึ่งใน: ${MENU_CATEGORIES.join(", ")}` });
  }
  if (q !== undefined && (typeof q !== "string" || q.length > 100)) {
    return res.status(400).json({ error: "q ต้องเป็นข้อความไม่เกิน 100 ตัวอักษร" });
  }

  try {
    const where = [];
    const params = [];
    if (available === "1") {
      where.push("available = ?");
      params.push(true);
    }
    if (category !== undefined) {
      where.push("category = ?");
      params.push(category);
    }
    if (q !== undefined && q.trim() !== "") {
      // escape อักขระพิเศษของ LIKE เพื่อให้ค้นหาตามตัวอักษรจริง
      const escaped = q.trim().replace(/[\\%_]/g, "\\$&");
      where.push("name LIKE ?");
      params.push(`%${escaped}%`);
    }

    // ใช้ placeholder (?) เพื่อป้องกัน SQL Injection
    const sql =
      "SELECT id, name, category, price, available FROM menu_items" +
      (where.length ? ` WHERE ${where.join(" AND ")}` : "") +
      " ORDER BY id";

    const [rows] = await pool.query(sql, params);
    res.json(rows.map(toMenuItem));
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถดึงข้อมูลเมนูได้");
  }
});

// GET /api/menu/:id : ดูเมนู 1 รายการ
app.get("/api/menu/:id", async (req, res) => {
  const id = Number(req.params.id);
  if (!isPositiveInt(id)) {
    return res.status(400).json({ error: "id ต้องเป็นจำนวนเต็มบวก" });
  }

  try {
    const [rows] = await pool.query(
      "SELECT id, name, category, price, available FROM menu_items WHERE id = ?",
      [id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ error: "ไม่พบเมนูนี้" });
    }
    res.json(toMenuItem(rows[0]));
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถดึงข้อมูลเมนูได้");
  }
});

// POST /api/menu : เพิ่มเมนูใหม่ (พนักงานเท่านั้น)
// body: { "name": "ชาไทย", "price": 30, "category": "เครื่องดื่ม", "available": true }
app.post("/api/menu", requireStaff, async (req, res) => {
  const error = checkMenuBody(req.body || {}, true);
  if (error) return res.status(400).json({ error });

  const { name, price, category, available } = req.body;
  try {
    const [result] = await pool.query(
      "INSERT INTO menu_items (name, category, price, available) VALUES (?, ?, ?, ?)",
      [name.trim(), category, price, available]
    );
    const [rows] = await pool.query(
      "SELECT id, name, category, price, available FROM menu_items WHERE id = ?",
      [result.insertId]
    );
    res.status(201).json(toMenuItem(rows[0]));
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถเพิ่มเมนูได้");
  }
});

// PUT /api/menu/:id : แก้ไขเมนู (พนักงานเท่านั้น) ต้องส่ง name, price, available
// category ไม่บังคับ ถ้าไม่ส่งจะคงหมวดหมู่เดิมไว้
app.put("/api/menu/:id", requireStaff, async (req, res) => {
  const id = Number(req.params.id);
  if (!isPositiveInt(id)) {
    return res.status(400).json({ error: "id ต้องเป็นจำนวนเต็มบวก" });
  }

  const error = checkMenuBody(req.body || {}, false);
  if (error) return res.status(400).json({ error });

  const { name, price, available, category } = req.body;
  try {
    const [existing] = await pool.query("SELECT id FROM menu_items WHERE id = ?", [id]);
    if (existing.length === 0) return res.status(404).json({ error: "ไม่พบเมนูนี้" });

    await pool.query(
      "UPDATE menu_items SET name = ?, price = ?, available = ?, category = COALESCE(?, category) WHERE id = ?",
      [name.trim(), price, available, category ?? null, id]
    );

    const [rows] = await pool.query(
      "SELECT id, name, category, price, available FROM menu_items WHERE id = ?",
      [id]
    );
    res.json(toMenuItem(rows[0]));
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถแก้ไขเมนูได้");
  }
});

// DELETE /api/menu/:id : ลบเมนู (พนักงานเท่านั้น)
// ลบไม่ได้ถ้าเมนูนี้เคยถูกสั่งแล้ว (มีในออเดอร์) ให้ใช้ PUT ตั้ง available เป็น false แทน
app.delete("/api/menu/:id", requireStaff, async (req, res) => {
  const id = Number(req.params.id);
  if (!isPositiveInt(id)) {
    return res.status(400).json({ error: "id ต้องเป็นจำนวนเต็มบวก" });
  }

  try {
    const [used] = await pool.query(
      "SELECT COUNT(*) AS total FROM order_items WHERE menu_item_id = ?",
      [id]
    );
    if (used[0].total > 0) {
      return res.status(409).json({
        error: "ลบไม่ได้ เพราะเมนูนี้มีอยู่ในออเดอร์แล้ว ให้แก้เป็นหมดแทน",
      });
    }

    const [result] = await pool.query("DELETE FROM menu_items WHERE id = ?", [id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: "ไม่พบเมนูนี้" });

    // 204 = ลบสำเร็จ ไม่มีเนื้อหาตอบกลับ
    res.status(204).end();
  } catch (err) {
    // ถ้ามีคนสั่งเมนูนี้พร้อมกันจนเกิดการอ้างอิงใหม่ ฐานข้อมูลจะปฏิเสธการลบ
    if (err.code === "ER_ROW_IS_REFERENCED_2") {
      return res.status(409).json({ error: "ลบไม่ได้ เพราะเมนูนี้ถูกใช้งานอยู่" });
    }
    sendServerError(res, err, "ไม่สามารถลบเมนูได้");
  }
});

// ---------- Endpoint: ออเดอร์ ----------

// POST /api/orders : สร้างออเดอร์ใหม่ (ลูกค้า)
// body: {
//   "customer_name": "สมชาย",
//   "delivery_info": "โต๊ะ 5",                       // ไม่บังคับ: หมายเลขโต๊ะหรือที่อยู่จัดส่ง
//   "items": [{ "menu_item_id": 1, "quantity": 2, "note": "ไม่ใส่ผัก" }]  // note ไม่บังคับ
// }
app.post("/api/orders", async (req, res) => {
  const { customer_name: customerName, items, delivery_info: deliveryInput } = req.body || {};

  // 1) ตรวจข้อมูลที่รับเข้ามา
  if (typeof customerName !== "string" || customerName.trim() === "" || customerName.trim().length > 100) {
    return res.status(400).json({ error: "customer_name ต้องเป็นข้อความ 1-100 ตัวอักษร" });
  }
  const deliveryInfo = cleanOptional(deliveryInput, 200);
  if (deliveryInfo === undefined) {
    return res.status(400).json({ error: "delivery_info ต้องเป็นข้อความไม่เกิน 200 ตัวอักษร" });
  }
  if (!Array.isArray(items) || items.length === 0 || items.length > 50) {
    return res.status(400).json({ error: "items ต้องเป็น array ที่มี 1-50 รายการ" });
  }
  for (const item of items) {
    if (!item || !isPositiveInt(item.menu_item_id) || !isPositiveInt(item.quantity) || item.quantity > 99) {
      return res.status(400).json({
        error: "แต่ละรายการต้องมี menu_item_id (จำนวนเต็มบวก) และ quantity (จำนวนเต็ม 1-99)",
      });
    }
    if (cleanOptional(item.note, 200) === undefined) {
      return res.status(400).json({ error: "note ของแต่ละรายการต้องเป็นข้อความไม่เกิน 200 ตัวอักษร" });
    }
  }

  try {
    // 2) ตรวจว่าเมนูทุกรายการมีอยู่จริงและพร้อมขาย
    const menuIds = [...new Set(items.map((item) => item.menu_item_id))];
    const [menuRows] = await pool.query(
      "SELECT id, available FROM menu_items WHERE id IN (?)",
      [menuIds]
    );
    const menuMap = new Map(menuRows.map((row) => [row.id, row]));
    for (const id of menuIds) {
      const menu = menuMap.get(id);
      if (!menu) return res.status(400).json({ error: `ไม่พบเมนู id ${id}` });
      if (!menu.available) return res.status(400).json({ error: `เมนู id ${id} หมดแล้ว` });
    }

    // 3) บันทึกออเดอร์และรายการอาหารในทรานแซกชันเดียวกัน
    // ถ้าขั้นตอนใดล้มเหลว ข้อมูลจะถูกยกเลิกทั้งหมด (rollback) ไม่ให้เหลือออเดอร์ครึ่ง ๆ
    const conn = await pool.getConnection();
    let orderId;
    try {
      await conn.beginTransaction();
      const [orderResult] = await conn.query(
        "INSERT INTO orders (customer_name, delivery_info) VALUES (?, ?)",
        [customerName.trim(), deliveryInfo]
      );
      orderId = orderResult.insertId;

      // ส่งหลายแถวพร้อมกันด้วย VALUES ? (mysql2 รองรับ array ซ้อน)
      const rows = items.map((item) => [
        orderId,
        item.menu_item_id,
        item.quantity,
        cleanOptional(item.note, 200),
      ]);
      await conn.query(
        "INSERT INTO order_items (order_id, menu_item_id, quantity, note) VALUES ?",
        [rows]
      );
      await conn.commit();
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release(); // คืน connection กลับเข้า pool ทุกกรณี
    }

    const order = await getOrderDetail(orderId);
    res.status(201).json(order);
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถสร้างออเดอร์ได้");
  }
});

// GET /api/orders : ดูรายการออเดอร์ทั้งหมด (พนักงานเท่านั้น) ?status=pending เพื่อกรองตามสถานะ
app.get("/api/orders", requireStaff, async (req, res) => {
  const { status } = req.query;
  if (status !== undefined && !ORDER_STATUSES.includes(status)) {
    return res.status(400).json({ error: `status ต้องเป็นหนึ่งใน: ${ORDER_STATUSES.join(", ")}` });
  }

  try {
    const sql = status
      ? "SELECT id, customer_name, status, created_at FROM orders WHERE status = ? ORDER BY id DESC"
      : "SELECT id, customer_name, status, created_at FROM orders ORDER BY id DESC";
    const [rows] = await pool.query(sql, status ? [status] : []);
    res.json(rows);
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถดึงรายการออเดอร์ได้");
  }
});

// GET /api/orders/:id : ดูรายละเอียดออเดอร์ 1 รายการ พร้อมยอดรวม (ลูกค้าใช้ติดตามสถานะได้)
app.get("/api/orders/:id", async (req, res) => {
  const id = Number(req.params.id);
  if (!isPositiveInt(id)) {
    return res.status(400).json({ error: "id ต้องเป็นจำนวนเต็มบวก" });
  }

  try {
    const order = await getOrderDetail(id);
    if (!order) return res.status(404).json({ error: "ไม่พบออเดอร์นี้" });
    res.json(order);
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถดึงข้อมูลออเดอร์ได้");
  }
});

// POST /api/orders/:id/cancel : ลูกค้ายกเลิกออเดอร์ของตัวเอง
// ทำได้เฉพาะตอนที่ยังเป็น pending (ร้านยังไม่รับออเดอร์เข้าครัว)
app.post("/api/orders/:id/cancel", async (req, res) => {
  const id = Number(req.params.id);
  if (!isPositiveInt(id)) {
    return res.status(400).json({ error: "id ต้องเป็นจำนวนเต็มบวก" });
  }

  try {
    // เงื่อนไข status = 'pending' อยู่ใน UPDATE เลย เพื่อกันกรณีร้านเปลี่ยนสถานะพร้อมกัน
    const [result] = await pool.query(
      "UPDATE orders SET status = 'cancelled' WHERE id = ? AND status = 'pending'",
      [id]
    );
    if (result.affectedRows === 0) {
      const [current] = await pool.query("SELECT status FROM orders WHERE id = ?", [id]);
      if (current.length === 0) return res.status(404).json({ error: "ไม่พบออเดอร์นี้" });
      return res.status(409).json({
        error: `ยกเลิกได้เฉพาะออเดอร์ที่ยังรอรับ ตอนนี้สถานะเป็น ${current[0].status}`,
      });
    }

    const order = await getOrderDetail(id);
    res.json(order);
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถยกเลิกออเดอร์ได้");
  }
});

// PATCH /api/orders/:id/status : เปลี่ยนสถานะออเดอร์ เช่น { "status": "preparing" } (พนักงานเท่านั้น)
app.patch("/api/orders/:id/status", requireStaff, async (req, res) => {
  const id = Number(req.params.id);
  if (!isPositiveInt(id)) {
    return res.status(400).json({ error: "id ต้องเป็นจำนวนเต็มบวก" });
  }

  const { status } = req.body || {};
  if (!ORDER_STATUSES.includes(status)) {
    return res.status(400).json({ error: `status ต้องเป็นหนึ่งใน: ${ORDER_STATUSES.join(", ")}` });
  }

  try {
    const [current] = await pool.query("SELECT status FROM orders WHERE id = ?", [id]);
    if (current.length === 0) return res.status(404).json({ error: "ไม่พบออเดอร์นี้" });

    // ออเดอร์ที่ส่งแล้วหรือยกเลิกแล้ว จะเปลี่ยนสถานะต่อไม่ได้
    if (FINAL_STATUSES.includes(current[0].status)) {
      return res.status(409).json({
        error: `ไม่สามารถเปลี่ยนสถานะได้ เพราะออเดอร์นี้ ${current[0].status} แล้ว`,
      });
    }

    await pool.query("UPDATE orders SET status = ? WHERE id = ?", [status, id]);
    const order = await getOrderDetail(id);
    res.json(order);
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถเปลี่ยนสถานะออเดอร์ได้");
  }
});

// DELETE /api/orders/:id : ลบออเดอร์ (พนักงานเท่านั้น)
// ลบได้เฉพาะออเดอร์ที่ยกเลิก (cancelled) แล้ว รายการอาหารในออเดอร์จะถูกลบตามด้วย (ON DELETE CASCADE)
app.delete("/api/orders/:id", requireStaff, async (req, res) => {
  const id = Number(req.params.id);
  if (!isPositiveInt(id)) {
    return res.status(400).json({ error: "id ต้องเป็นจำนวนเต็มบวก" });
  }

  try {
    const [current] = await pool.query("SELECT status FROM orders WHERE id = ?", [id]);
    if (current.length === 0) return res.status(404).json({ error: "ไม่พบออเดอร์นี้" });

    if (current[0].status !== "cancelled") {
      return res.status(409).json({
        error: `ลบได้เฉพาะออเดอร์ที่ยกเลิกแล้ว ตอนนี้สถานะเป็น ${current[0].status}`,
      });
    }

    await pool.query("DELETE FROM orders WHERE id = ?", [id]);
    res.status(204).end();
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถลบออเดอร์ได้");
  }
});

// ---------- จัดการข้อผิดพลาดทั่วไป ----------

// ถ้าส่ง JSON ที่รูปแบบผิด ให้ตอบ 400 ในรูปแบบ JSON แทนหน้า HTML ของ Express
app.use((err, req, res, next) => {
  if (err.type === "entity.parse.failed") {
    return res.status(400).json({ error: "รูปแบบ JSON ไม่ถูกต้อง" });
  }
  next(err);
});

// เปิดเซิร์ฟเวอร์เฉพาะตอนรันไฟล์นี้โดยตรง (node app.js)
// ถ้า require จากเทสต์ จะไม่เปิดพอร์ตซ้ำ
if (require.main === module) {
  app.listen(port, () => {
    console.log(`เปิดหน้าเว็บลูกค้าที่ http://localhost:${port}`);
    console.log(`เปิดหน้าร้านค้าที่ http://localhost:${port}/kitchen.html`);
  });
}

module.exports = app;
