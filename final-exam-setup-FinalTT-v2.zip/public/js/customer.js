// ---------- หน้าลูกค้า: เมนู ตะกร้า สั่งอาหาร และติดตามสถานะ ----------

const CART_KEY = "food-cart";             // เก็บตะกร้าไว้ในเบราว์เซอร์ของผู้ใช้
const LAST_ORDER_KEY = "food-last-order"; // เก็บหมายเลขออเดอร์ล่าสุด
const REFRESH_MS = 10000;                 // ดึงสถานะออเดอร์ใหม่ทุก 10 วินาที

const menuList = document.getElementById("menu");
const statusBox = document.getElementById("status");
const countLabel = document.getElementById("count");
const filterBox = document.getElementById("onlyAvailable");
const searchBox = document.getElementById("searchBox");
const categoryFilter = document.getElementById("categoryFilter");
const cartItemsEl = document.getElementById("cartItems");
const cartEmptyEl = document.getElementById("cartEmpty");
const cartTotalEl = document.getElementById("cartTotal");
const orderForm = document.getElementById("orderForm");
const customerNameInput = document.getElementById("customerName");
const deliveryInput = document.getElementById("deliveryInfo");
const submitBtn = document.getElementById("submitBtn");
const formMessage = document.getElementById("formMessage");
const trackForm = document.getElementById("trackForm");
const trackIdInput = document.getElementById("trackId");
const orderResultEl = document.getElementById("orderResult");

let menuData = [];           // เมนูทั้งหมดจาก API
let cart = loadCart();       // ตะกร้า: [{ id, qty, note }]
let trackedId = null;        // ออเดอร์ที่กำลังติดตามอยู่
let refreshTimer = null;     // ตัวจับเวลาดึงสถานะใหม่

// ชื่อสถานะออเดอร์เป็นภาษาไทย
const STATUS_LABEL = {
  pending: "รอรับออเดอร์",
  preparing: "กำลังเตรียมอาหาร",
  delivered: "ส่งให้ลูกค้าแล้ว",
  cancelled: "ยกเลิกแล้ว",
};
const FINAL_STATUSES = ["delivered", "cancelled"];

// จัดรูปแบบราคาเป็นเงินบาท เช่น ฿60.00
const formatPrice = (value) =>
  new Intl.NumberFormat("th-TH", { style: "currency", currency: "THB" }).format(value);

// ---------- เก็บข้อมูลในเบราว์เซอร์ (ถ้าใช้ไม่ได้ก็ไม่ทำให้หน้าพัง) ----------
function loadCart() {
  try {
    const data = JSON.parse(localStorage.getItem(CART_KEY) || "[]");
    if (!Array.isArray(data)) return [];
    // คัดเฉพาะรายการที่รูปแบบถูกต้อง
    return data
      .filter((c) => Number.isInteger(c.id) && Number.isInteger(c.qty) && c.qty >= 1 && c.qty <= 99)
      .map((c) => ({ id: c.id, qty: c.qty, note: typeof c.note === "string" ? c.note.slice(0, 200) : "" }));
  } catch (err) {
    return [];
  }
}

function saveCart() {
  try {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
  } catch (err) {
    // ไม่ได้บันทึกก็ยังใช้งานต่อได้ในหน้านี้
  }
}

function saveLastOrderId(id) {
  try {
    localStorage.setItem(LAST_ORDER_KEY, String(id));
  } catch (err) { /* ไม่เป็นไร */ }
}

function getLastOrderId() {
  try {
    return localStorage.getItem(LAST_ORDER_KEY);
  } catch (err) {
    return null;
  }
}

// ---------- ข้อความแจ้งเตือน ----------
function showFormMessage(text, isError) {
  formMessage.textContent = text;
  formMessage.className = isError ? "message error" : "message success";
  formMessage.hidden = false;
}

function showStatus(message, isError = false) {
  statusBox.textContent = message;
  statusBox.className = isError ? "status-box error" : "status-box";
  statusBox.hidden = false;
}

// ---------- ตะกร้า ----------
// เพิ่มเมนู 1 ชิ้นลงตะกร้า (สูงสุด 99 ชิ้นต่อรายการ ตามที่ API กำหนด)
function addToCart(id) {
  const existing = cart.find((c) => c.id === id);
  if (existing) {
    existing.qty = Math.min(99, existing.qty + 1);
  } else {
    cart.push({ id, qty: 1, note: "" });
  }
  saveCart();
  renderCart();
}

// เปลี่ยนจำนวน (delta = +1 หรือ -1) ถ้าเหลือ 0 ให้เอาออกจากตะกร้า
function changeQty(id, delta) {
  const item = cart.find((c) => c.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty < 1) {
    cart = cart.filter((c) => c.id !== id);
  } else if (item.qty > 99) {
    item.qty = 99;
  }
  saveCart();
  renderCart();
}

// วาดรายการในตะกร้าใหม่ และคำนวณยอดรวมจากราคาเมนูปัจจุบัน
function renderCart() {
  cartItemsEl.replaceChildren();
  let total = 0;

  for (const line of cart) {
    const menu = menuData.find((m) => m.id === line.id);
    if (!menu) continue; // ไม่พบในเมนู (จะถูกลบตอนโหลดเมนูครั้งถัดไป)

    const subtotal = menu.price * line.qty;
    total += subtotal;

    const li = document.createElement("li");
    li.className = "cart-line";

    const nameEl = document.createElement("span");
    nameEl.textContent = menu.name;

    const subtotalEl = document.createElement("span");
    subtotalEl.className = "subtotal";
    subtotalEl.textContent = formatPrice(subtotal);

    // ปุ่มลด/เพิ่มจำนวน
    const qtyBox = document.createElement("div");
    qtyBox.className = "qty";

    const minus = document.createElement("button");
    minus.type = "button";
    minus.className = "btn ghost small";
    minus.textContent = "−";
    minus.setAttribute("aria-label", "ลดจำนวน");
    minus.addEventListener("click", () => changeQty(line.id, -1));

    const qtyText = document.createElement("span");
    qtyText.textContent = String(line.qty);

    const plus = document.createElement("button");
    plus.type = "button";
    plus.className = "btn ghost small";
    plus.textContent = "+";
    plus.setAttribute("aria-label", "เพิ่มจำนวน");
    plus.addEventListener("click", () => changeQty(line.id, 1));

    qtyBox.append(minus, qtyText, plus);

    // ช่องหมายเหตุของรายการ เช่น ไม่ใส่ผัก
    const noteWrap = document.createElement("div");
    noteWrap.className = "note-field";
    const noteInput = document.createElement("input");
    noteInput.type = "text";
    noteInput.maxLength = 200;
    noteInput.placeholder = "หมายเหตุ เช่น ไม่ใส่ผัก";
    noteInput.value = line.note;
    noteInput.setAttribute("aria-label", `หมายเหตุของ ${menu.name}`);
    noteInput.addEventListener("input", () => {
      line.note = noteInput.value.slice(0, 200);
      saveCart();
    });
    noteWrap.appendChild(noteInput);

    li.append(nameEl, subtotalEl, qtyBox, noteWrap);
    cartItemsEl.appendChild(li);
  }

  const hasItems = cartItemsEl.children.length > 0;
  cartEmptyEl.hidden = hasItems;
  cartTotalEl.textContent = formatPrice(total);
  submitBtn.disabled = !hasItems;
}

// ตรวจตะกร้ากับเมนูล่าสุด: ถ้ามีรายการที่หมดแล้ว ให้เอาออกและแจ้งผู้ใช้
function pruneCart() {
  const before = cart.length;
  cart = cart.filter((c) => menuData.some((m) => m.id === c.id && m.available));
  if (cart.length !== before) {
    saveCart();
    showFormMessage("เมนูบางรายการหมดแล้วและถูกนำออกจากตะกร้า", true);
  }
}

// ---------- เมนู ----------
// สร้างการ์ดเมนู 1 ใบ พร้อมปุ่มเพิ่มลงตะกร้า
// ใช้ textContent เพื่อความปลอดภัย (ป้องกัน XSS)
function createMenuCard(item) {
  const li = document.createElement("li");
  li.className = item.available ? "menu-card" : "menu-card unavailable";

  const category = document.createElement("span");
  category.className = "badge category";
  category.textContent = item.category;

  const name = document.createElement("p");
  name.className = "name";
  name.textContent = item.name;

  const price = document.createElement("p");
  price.className = "price";
  price.textContent = formatPrice(item.price);

  const badge = document.createElement("span");
  badge.className = item.available ? "badge ok" : "badge off";
  badge.textContent = item.available ? "พร้อมขาย" : "หมด";

  const addBtn = document.createElement("button");
  addBtn.type = "button";
  addBtn.className = "btn add-btn";
  addBtn.textContent = item.available ? "+ เพิ่มลงตะกร้า" : "หมดแล้ว";
  addBtn.disabled = !item.available; // เมนูที่หมดจะกดไม่ได้
  addBtn.addEventListener("click", () => addToCart(item.id));

  li.append(category, name, price, badge, addBtn);
  return li;
}

// วาดรายการเมนูตามตัวกรอง: คำค้นหา หมวดหมู่ และสถานะพร้อมขาย
// กรองในเครื่องจากเมนูที่โหลดมาแล้ว เพื่อให้ตะกร้ายังเห็นเมนูครบ
function renderMenu() {
  const query = searchBox.value.trim().toLowerCase();
  const category = categoryFilter.value;
  const onlyAvailable = filterBox.checked;

  const items = menuData.filter((m) => {
    if (onlyAvailable && !m.available) return false;
    if (category && m.category !== category) return false;
    if (query && !m.name.toLowerCase().includes(query)) return false;
    return true;
  });

  menuList.replaceChildren();
  items.forEach((item) => menuList.appendChild(createMenuCard(item)));

  countLabel.textContent = `ทั้งหมด ${items.length} รายการ`;
  if (items.length === 0) {
    showStatus("ไม่พบเมนูที่ตรงกับการค้นหา");
  } else {
    statusBox.hidden = true;
  }
}

// โหลดเมนูทั้งหมดจาก API
async function loadMenu() {
  showStatus("กำลังโหลดเมนู...");
  try {
    const response = await fetch("/api/menu");
    if (!response.ok) throw new Error(`เซิร์ฟเวอร์ตอบกลับ ${response.status}`);
    menuData = await response.json();
    pruneCart();
    renderMenu();
    renderCart();
  } catch (err) {
    console.error(err);
    showStatus("โหลดเมนูไม่สำเร็จ กรุณาลองใหม่อีกครั้ง", true);
  }
}

// ---------- ออเดอร์ ----------
// วาดรายละเอียดออเดอร์ (ใช้ทั้งตอนสั่งสำเร็จ ตอนติดตามสถานะ และตอนยกเลิก)
function renderOrderDetail(order) {
  const box = document.createElement("div");
  box.className = "order-box";

  const title = document.createElement("h3");
  title.textContent = `ออเดอร์ #${order.id}`;

  const customer = document.createElement("p");
  customer.textContent = `ผู้สั่ง: ${order.customer_name}`;
  customer.style.margin = "0";

  if (order.delivery_info) {
    const place = document.createElement("p");
    place.textContent = `โต๊ะ/ที่อยู่: ${order.delivery_info}`;
    place.style.margin = "0";
    box.appendChild(place);
  }

  const badge = document.createElement("span");
  badge.className = `badge ${order.status}`;
  badge.textContent = STATUS_LABEL[order.status] || order.status;
  badge.style.display = "inline-block";
  badge.style.margin = "6px 0";

  const time = document.createElement("p");
  time.className = "time";
  time.textContent = `สั่งเมื่อ ${new Date(order.created_at).toLocaleString("th-TH")}`;

  const list = document.createElement("ul");
  for (const item of order.items) {
    const li = document.createElement("li");
    const label = document.createElement("span");
    label.textContent = `${item.name} × ${item.quantity}`;
    if (item.note) {
      const note = document.createElement("small");
      note.textContent = `หมายเหตุ: ${item.note}`;
      label.appendChild(note);
    }
    const amount = document.createElement("span");
    amount.textContent = formatPrice(item.subtotal);
    li.append(label, amount);
    list.appendChild(li);
  }

  const total = document.createElement("p");
  total.className = "total";
  total.textContent = `รวม ${formatPrice(order.total)}`;

  box.append(title, customer, badge, time, list, total);

  // ลูกค้ายกเลิกได้เฉพาะตอนที่ร้านยังไม่รับเข้าครัว
  if (order.status === "pending") {
    const cancelBtn = document.createElement("button");
    cancelBtn.type = "button";
    cancelBtn.className = "btn danger small";
    cancelBtn.textContent = "ยกเลิกออเดอร์";
    cancelBtn.addEventListener("click", () => cancelOrder(order.id));
    box.appendChild(cancelBtn);
  }

  if (!FINAL_STATUSES.includes(order.status)) {
    const hint = document.createElement("p");
    hint.className = "refresh-hint";
    hint.textContent = "สถานะจะอัปเดตอัตโนมัติทุก 10 วินาที";
    box.appendChild(hint);
  }

  orderResultEl.replaceChildren(box);
}

// แสดงข้อความผิดพลาดในกล่องติดตามออเดอร์
function showOrderError(text) {
  const msg = document.createElement("p");
  msg.className = "message error";
  msg.textContent = text;
  orderResultEl.replaceChildren(msg);
}

// เริ่มดึงสถานะออเดอร์ใหม่เป็นระยะ (ถ้ายังไม่ได้เริ่มอยู่)
function ensureAutoRefresh() {
  if (refreshTimer) return;
  refreshTimer = setInterval(() => {
    if (trackedId) showOrder(trackedId, false);
  }, REFRESH_MS);
}

// หยุดดึงสถานะใหม่ (ใช้เมื่อออเดอร์จบแล้ว)
function stopAutoRefresh() {
  clearInterval(refreshTimer);
  refreshTimer = null;
}

// ดึงและแสดงสถานะออเดอร์ 1 รายการ
// showErrors = false ตอนรีเฟรชอัตโนมัติ เพื่อไม่ให้ข้อความผิดพลาดกวนผู้ใช้
async function showOrder(id, showErrors) {
  try {
    const response = await fetch(`/api/orders/${id}`);
    const data = await response.json().catch(() => ({}));
    if (response.status === 404) {
      if (showErrors) showOrderError("ไม่พบออเดอร์นี้");
      return;
    }
    if (!response.ok) throw new Error(data.error || "ตรวจสอบสถานะไม่สำเร็จ");

    renderOrderDetail(data);
    if (FINAL_STATUSES.includes(data.status)) {
      stopAutoRefresh(); // ออเดอร์จบแล้ว ไม่ต้องดึงซ้ำ
    } else {
      ensureAutoRefresh();
    }
  } catch (err) {
    if (showErrors) showOrderError(err.message);
  }
}

// เริ่มติดตามออเดอร์หมายเลขที่ระบุ
async function trackOrder(id) {
  trackedId = id;
  saveLastOrderId(id);
  await showOrder(id, true);
}

// ลูกค้ายกเลิกออเดอร์ของตัวเอง (เฉพาะตอนยังรอรับ)
async function cancelOrder(id) {
  if (!confirm(`ยืนยันการยกเลิกออเดอร์ #${id} ?`)) return;
  try {
    const response = await fetch(`/api/orders/${id}/cancel`, { method: "POST" });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "ยกเลิกออเดอร์ไม่สำเร็จ");
    renderOrderDetail(data);
    stopAutoRefresh();
  } catch (err) {
    showOrderError(err.message);
  }
}

// ส่งตะกร้าไปสร้างออเดอร์ที่เซิร์ฟเวอร์
orderForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const name = customerNameInput.value.trim();
  if (name === "") {
    showFormMessage("กรุณาใส่ชื่อผู้สั่ง", true);
    return;
  }
  if (cart.length === 0) {
    showFormMessage("ตะกร้าว่างอยู่", true);
    return;
  }

  submitBtn.disabled = true;
  submitBtn.textContent = "กำลังส่งออเดอร์...";
  try {
    const response = await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        customer_name: name,
        delivery_info: deliveryInput.value.trim(),
        items: cart.map((c) => ({
          menu_item_id: c.id,
          quantity: c.qty,
          note: c.note.trim(),
        })),
      }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `สั่งอาหารไม่สำเร็จ (${response.status})`);

    // สั่งสำเร็จ: ล้างตะกร้า แสดงผล และเริ่มติดตามออเดอร์นี้
    cart = [];
    saveCart();
    customerNameInput.value = "";
    deliveryInput.value = "";
    trackIdInput.value = data.id;
    trackedId = data.id;
    saveLastOrderId(data.id);
    renderOrderDetail(data);
    ensureAutoRefresh();
    showFormMessage(`สั่งอาหารสำเร็จ หมายเลขออเดอร์ของคุณคือ #${data.id}`, false);
    loadMenu(); // โหลดเมนูใหม่ เผื่อบางรายการหมดระหว่างสั่ง
  } catch (err) {
    showFormMessage(err.message, true);
  } finally {
    submitBtn.textContent = "ยืนยันการสั่งอาหาร";
    renderCart(); // ตั้งสถานะปุ่มตามตะกร้าปัจจุบัน
  }
});

trackForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const id = Number(trackIdInput.value);
  if (!Number.isInteger(id) || id < 1) {
    showOrderError("กรุณาใส่หมายเลขออเดอร์ให้ถูกต้อง");
    return;
  }
  trackOrder(id);
});

// ---------- เริ่มต้นหน้าเว็บ ----------
// ตัวกรองเมนูทำงานทันทีที่พิมพ์หรือเปลี่ยนหมวดหมู่
searchBox.addEventListener("input", renderMenu);
categoryFilter.addEventListener("change", renderMenu);
filterBox.addEventListener("change", renderMenu);

loadMenu();

// ถ้าเคยสั่งไว้ ให้แสดงสถานะออเดอร์ล่าสุดทันที
const lastId = getLastOrderId();
if (lastId && Number.isInteger(Number(lastId))) {
  trackIdInput.value = lastId;
  trackOrder(Number(lastId));
}
