// ---------- หน้าร้านค้า: เข้าสู่ระบบ จัดการออเดอร์ และจัดการเมนู ----------
// ทุกคำขอส่ง token ของพนักงานไปด้วย (JWT จาก POST /api/auth/login)

const TOKEN_KEY = "kitchen-token";  // เก็บ token ไว้ในเบราว์เซอร์ของพนักงาน
const REFRESH_MS = 10000;           // ดึงรายการออเดอร์ใหม่ทุก 10 วินาที

const STATUS_LABEL = {
  pending: "รอรับออเดอร์",
  preparing: "กำลังเตรียมอาหาร",
  delivered: "ส่งให้ลูกค้าแล้ว",
  cancelled: "ยกเลิกแล้ว",
};

const loginPanel = document.getElementById("loginPanel");
const workPanel = document.getElementById("workPanel");
const logoutArea = document.getElementById("logoutArea");
const loginForm = document.getElementById("loginForm");
const loginMessage = document.getElementById("loginMessage");
const orderFilter = document.getElementById("orderFilter");
const orderList = document.getElementById("orderList");
const orderMessage = document.getElementById("orderMessage");
const menuForm = document.getElementById("menuForm");
const menuMessage = document.getElementById("menuMessage");
const menuAdminList = document.getElementById("menuAdminList");
const menuSearch = document.getElementById("menuSearch");

let refreshTimer = null;
let allMenu = [];  // เมนูทั้งหมดสำหรับหน้าจัดการเมนู

const formatPrice = (value) =>
  new Intl.NumberFormat("th-TH", { style: "currency", currency: "THB" }).format(value);

// ---------- token ----------
const getToken = () => {
  try { return localStorage.getItem(TOKEN_KEY); } catch (err) { return null; }
};
const setToken = (token) => {
  try { localStorage.setItem(TOKEN_KEY, token); } catch (err) { /* ไม่เป็นไร */ }
};
const clearToken = () => {
  try { localStorage.removeItem(TOKEN_KEY); } catch (err) { /* ไม่เป็นไร */ }
};

// เรียก API ของพนักงาน: แนบ token อัตโนมัติ และถ้า token หมดอายุ (401) ให้กลับไปหน้าเข้าสู่ระบบ
async function staffFetch(path, options = {}) {
  const headers = { ...(options.headers || {}), Authorization: `Bearer ${getToken()}` };
  if (options.body !== undefined) headers["Content-Type"] = "application/json";
  const response = await fetch(path, {
    method: options.method || "GET",
    headers,
    body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
  });
  if (response.status === 401) {
    showLogin("เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่");
    throw new Error("unauthorized");
  }
  if (response.status === 204) return null;
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `เกิดข้อผิดพลาด (${response.status})`);
  return data;
}

// ---------- การแสดงหน้า ----------
function showLogin(message = "") {
  stopRefresh();
  clearToken();
  workPanel.hidden = true;
  logoutArea.hidden = true;
  loginPanel.hidden = false;
  loginMessage.textContent = message;
  loginMessage.hidden = message === "";
}

function showWork() {
  loginPanel.hidden = true;
  logoutArea.hidden = false;
  workPanel.hidden = false;
  loadOrders();
  loadMenuAdmin();
  stopRefresh();
  refreshTimer = setInterval(loadOrders, REFRESH_MS);
}

function stopRefresh() {
  clearInterval(refreshTimer);
  refreshTimer = null;
}

function showMessage(el, text, isError) {
  el.textContent = text;
  el.className = isError ? "message error" : "message success";
  el.hidden = false;
}

// ---------- เข้าสู่ระบบ / ออกจากระบบ ----------
loginForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value;
  try {
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "เข้าสู่ระบบไม่สำเร็จ");
    setToken(data.token);
    document.getElementById("password").value = "";
    loginMessage.hidden = true;
    showWork();
  } catch (err) {
    showMessage(loginMessage, err.message, true);
  }
});

document.getElementById("logoutBtn").addEventListener("click", () => showLogin());

// ---------- ออเดอร์ ----------
// ปุ่มที่ควรแสดงตามสถานะปัจจุบันของออเดอร์
function actionsFor(status) {
  if (status === "pending") return [["รับออเดอร์ (เริ่มเตรียม)", "preparing", ""], ["ยกเลิก", "cancelled", "danger"]];
  if (status === "preparing") return [["ส่งให้ลูกค้าแล้ว", "delivered", ""], ["ยกเลิก", "cancelled", "danger"]];
  if (status === "cancelled") return [["ลบออเดอร์", "delete", "danger"]];
  return [];
}

// เปลี่ยนสถานะออเดอร์ หรือลบออเดอร์ที่ยกเลิกแล้ว
async function applyAction(orderId, action) {
  try {
    if (action === "delete") {
      if (!confirm(`ลบออเดอร์ #${orderId} ?`)) return;
      await staffFetch(`/api/orders/${orderId}`, { method: "DELETE" });
    } else {
      await staffFetch(`/api/orders/${orderId}/status`, { method: "PATCH", body: { status: action } });
    }
    loadOrders();
  } catch (err) {
    if (err.message !== "unauthorized") showMessage(orderMessage, err.message, true);
  }
}

// สร้างการ์ดออเดอร์ 1 ใบ พร้อมรายการอาหารและหมายเหตุ
function createOrderCard(order) {
  const li = document.createElement("li");
  li.className = "order-card";

  const head = document.createElement("header");
  head.className = "order-head";
  const title = document.createElement("h3");
  title.textContent = `ออเดอร์ #${order.id} · ${order.customer_name}`;
  const badge = document.createElement("span");
  badge.className = `badge ${order.status}`;
  badge.textContent = STATUS_LABEL[order.status] || order.status;
  head.append(title, badge);

  const body = document.createElement("div");
  const list = document.createElement("ul");
  for (const item of order.items) {
    const row = document.createElement("li");
    row.textContent = `${item.name} × ${item.quantity}`;
    if (item.note) {
      const note = document.createElement("small");
      note.textContent = ` (หมายเหตุ: ${item.note})`;
      row.appendChild(note);
    }
    list.appendChild(row);
  }
  body.appendChild(list);

  const info = document.createElement("p");
  info.className = "muted";
  info.style.margin = "0";
  const parts = [];
  if (order.delivery_info) parts.push(`โต๊ะ/ที่อยู่: ${order.delivery_info}`);
  parts.push(`รวม ${formatPrice(order.total)}`);
  parts.push(new Date(order.created_at).toLocaleString("th-TH"));
  info.textContent = parts.join(" · ");

  li.append(head, body, info);

  const actions = actionsFor(order.status);
  if (actions.length) {
    const bar = document.createElement("div");
    bar.className = "actions";
    for (const [label, action, style] of actions) {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = style ? `btn small ${style}` : "btn small";
      btn.textContent = label;
      btn.addEventListener("click", () => applyAction(order.id, action));
      bar.appendChild(btn);
    }
    li.appendChild(bar);
  }
  return li;
}

// โหลดรายการออเดอร์ตามตัวกรอง แล้วดึงรายละเอียด (รายการอาหาร) ของแต่ละออเดอร์
async function loadOrders() {
  if (!getToken()) return;
  try {
    const status = orderFilter.value;
    const query = status ? `?status=${encodeURIComponent(status)}` : "";
    const summaries = await staffFetch(`/api/orders${query}`);
    const details = await Promise.all(summaries.map((o) => staffFetch(`/api/orders/${o.id}`)));

    orderList.replaceChildren();
    if (details.length === 0) {
      const empty = document.createElement("p");
      empty.className = "empty";
      empty.textContent = "ยังไม่มีออเดอร์";
      orderList.appendChild(empty);
    }
    details.forEach((order) => orderList.appendChild(createOrderCard(order)));
    orderMessage.hidden = true;
  } catch (err) {
    if (err.message !== "unauthorized") showMessage(orderMessage, err.message, true);
  }
}

orderFilter.addEventListener("change", loadOrders);

// ---------- จัดการเมนู ----------
// สร้างแถวเมนู 1 รายการ พร้อมปุ่มเปิด/ปิดการขายและปุ่มลบ
function createMenuRow(item) {
  const row = document.createElement("div");
  row.className = "menu-admin-row";

  const info = document.createElement("div");
  const name = document.createElement("strong");
  name.textContent = item.name;
  const meta = document.createElement("small");
  meta.textContent = ` ${item.category} · ${formatPrice(item.price)}`;
  info.append(name, meta);

  const actions = document.createElement("div");
  actions.className = "actions";

  const toggle = document.createElement("button");
  toggle.type = "button";
  toggle.className = item.available ? "btn ghost small" : "btn small";
  toggle.textContent = item.available ? "ตั้งเป็นหมด" : "ตั้งเป็นพร้อมขาย";
  toggle.addEventListener("click", () => toggleAvailable(item));

  const del = document.createElement("button");
  del.type = "button";
  del.className = "btn danger small";
  del.textContent = "ลบ";
  del.addEventListener("click", () => deleteMenu(item));

  actions.append(toggle, del);
  row.append(info, actions);
  return row;
}

// วาดรายการเมนูตามคำค้นหาในหน้าจัดการ
function renderMenuAdmin() {
  const query = menuSearch.value.trim().toLowerCase();
  const items = allMenu.filter((m) => !query || m.name.toLowerCase().includes(query));
  menuAdminList.replaceChildren();
  items.forEach((item) => menuAdminList.appendChild(createMenuRow(item)));
}

async function loadMenuAdmin() {
  try {
    allMenu = await fetch("/api/menu").then((r) => r.json());
    renderMenuAdmin();
  } catch (err) {
    showMessage(menuMessage, "โหลดรายการเมนูไม่สำเร็จ", true);
  }
}

// เปิด/ปิดการขายเมนู ใช้ PUT ที่ต้องส่งชื่อ ราคา และ available ครบ
async function toggleAvailable(item) {
  try {
    await staffFetch(`/api/menu/${item.id}`, {
      method: "PUT",
      body: { name: item.name, price: item.price, available: !item.available },
    });
    showMessage(menuMessage, `อัปเดต "${item.name}" แล้ว`, false);
    loadMenuAdmin();
  } catch (err) {
    if (err.message !== "unauthorized") showMessage(menuMessage, err.message, true);
  }
}

// ลบเมนู (ลบได้เฉพาะเมนูที่ยังไม่เคยถูกสั่ง)
async function deleteMenu(item) {
  if (!confirm(`ลบเมนู "${item.name}" ?`)) return;
  try {
    await staffFetch(`/api/menu/${item.id}`, { method: "DELETE" });
    showMessage(menuMessage, `ลบ "${item.name}" แล้ว`, false);
    loadMenuAdmin();
  } catch (err) {
    if (err.message !== "unauthorized") showMessage(menuMessage, err.message, true);
  }
}

// เพิ่มเมนูใหม่ด้วย POST /api/menu
menuForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const body = {
    name: document.getElementById("menuName").value.trim(),
    price: Number(document.getElementById("menuPrice").value),
    category: document.getElementById("menuCategory").value,
    available: document.getElementById("menuAvailable").checked,
  };
  try {
    const created = await staffFetch("/api/menu", { method: "POST", body });
    menuForm.reset();
    document.getElementById("menuAvailable").checked = true;
    showMessage(menuMessage, `เพิ่ม "${created.name}" แล้ว`, false);
    loadMenuAdmin();
  } catch (err) {
    if (err.message !== "unauthorized") showMessage(menuMessage, err.message, true);
  }
});

menuSearch.addEventListener("input", renderMenuAdmin);

// ---------- เริ่มต้น ----------
if (getToken()) {
  showWork();
} else {
  showLogin();
}
