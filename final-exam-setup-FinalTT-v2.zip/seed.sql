-- โครงสร้างและข้อมูลตัวอย่างของระบบสั่งอาหารออนไลน์
-- รัน: npm run seed  (จะลบข้อมูลเดิมและสร้างตารางใหม่ทั้งหมด)
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS menu_items;

CREATE TABLE menu_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  category VARCHAR(50) NOT NULL DEFAULT 'อาหาร',
  price DECIMAL(10, 2) NOT NULL,
  available BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_name VARCHAR(100) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  delivery_info VARCHAR(200) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  menu_item_id INT NOT NULL,
  quantity INT NOT NULL,
  note VARCHAR(200) NULL,
  CONSTRAINT fk_oi_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  CONSTRAINT fk_oi_menu FOREIGN KEY (menu_item_id) REFERENCES menu_items(id)
);

INSERT INTO menu_items (name, category, price, available) VALUES
('ข้าวผัดกุ้ง', 'อาหาร', 60.00, TRUE),
('ผัดกะเพราหมูสับ', 'อาหาร', 50.00, TRUE),
('ก๋วยเตี๋ยวเรือ', 'อาหาร', 55.00, TRUE),
('ข้าวมันไก่', 'อาหาร', 50.00, TRUE),
('ส้มตำไทย', 'อาหาร', 40.00, TRUE),
('ไก่ทอด 2 ชิ้น', 'อาหาร', 45.00, TRUE),
('ต้มยำกุ้ง', 'อาหาร', 90.00, TRUE),
('แกงเขียวหวานไก่', 'อาหาร', 65.00, TRUE),
('ข้าวขาหมู', 'อาหาร', 70.00, FALSE),
('ผัดไทยกุ้งสด', 'อาหาร', 75.00, TRUE),
('สเต็กไก่', 'อาหาร', 120.00, TRUE),
('ยำวุ้นเส้น', 'อาหาร', 45.00, TRUE),
('ข้าวราดแกงจืด', 'อาหาร', 40.00, TRUE),
('ลาบหมู', 'อาหาร', 55.00, TRUE),
('ชาเย็น', 'เครื่องดื่ม', 25.00, TRUE),
('น้ำมะนาว', 'เครื่องดื่ม', 20.00, TRUE),
('กาแฟเย็น', 'เครื่องดื่ม', 35.00, TRUE),
('น้ำแตงโม', 'เครื่องดื่ม', 30.00, FALSE),
('ขนมปังปิ้ง', 'ของหวาน', 25.00, TRUE),
('บิงซู', 'ของหวาน', 85.00, TRUE),
('ข้าวไข่เจียวหมูสับ', 'อาหาร', 55.00, TRUE),
('สุกี้น้ำ', 'อาหาร', 110.00, TRUE);

INSERT INTO orders (customer_name, status, delivery_info, created_at) VALUES
('สมชาย', 'delivered', 'โต๊ะ 3', '2026-01-10 12:00:00'),
('สมหญิง', 'preparing', NULL, '2026-01-10 12:30:00'),
('วิชัย', 'pending', 'โต๊ะ 7', '2026-01-10 13:00:00');

INSERT INTO order_items (order_id, menu_item_id, quantity, note) VALUES
(1, 1, 2, 'ไม่ใส่ผัก'),
(1, 15, 2, NULL),
(2, 6, 1, NULL),
(3, 7, 1, 'ไม่ใส่ถั่วงอก'),
(3, 16, 2, NULL);
