// เทสต์ API ของระบบสั่งอาหารด้วย Supertest (npm test)
// ต้องเปิดฐานข้อมูลและรัน npm run seed ก่อน เพราะเทสต์อ่านและเขียนข้อมูลจริง
const request = require("supertest");
const app = require("../app");
const { pool } = require("../db");
const { staff } = require("../config");

let token;

beforeAll(async () => {
  const res = await request(app)
    .post("/api/auth/login")
    .send({ username: staff.username, password: staff.password });
  token = res.body.token;
});

afterAll(async () => {
  await pool.end(); // ปิด connection pool ไม่ให้ Jest ค้างรอ
});

describe("การเข้าสู่ระบบพนักงาน", () => {
  it("ล็อกอินด้วยรหัสที่ถูกต้องได้ token", () => {
    expect(typeof token).toBe("string");
    expect(token.length).toBeGreaterThan(10);
  });

  it("รหัสผ่านผิดได้ 401", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({ username: staff.username, password: "wrong-password" });
    expect(res.statusCode).toBe(401);
  });

  it("ไม่ส่ง username/password ได้ 400", async () => {
    const res = await request(app).post("/api/auth/login").send({});
    expect(res.statusCode).toBe(400);
  });

  it("endpoint ของพนักงานที่ไม่มี token ได้ 401", async () => {
    const res = await request(app).get("/api/orders");
    expect(res.statusCode).toBe(401);
  });
});

describe("เมนู", () => {
  it("กรองตามหมวดหมู่ได้", async () => {
    const res = await request(app).get("/api/menu?category=เครื่องดื่ม");
    expect(res.statusCode).toBe(200);
    expect(res.body.length).toBeGreaterThan(0);
    expect(res.body.every((m) => m.category === "เครื่องดื่ม")).toBe(true);
  });

  it("ค้นหาเมนูจากชื่อได้", async () => {
    const res = await request(app).get("/api/menu?q=กุ้ง");
    expect(res.statusCode).toBe(200);
    expect(res.body.every((m) => m.name.includes("กุ้ง"))).toBe(true);
  });

  it("หมวดหมู่ที่ไม่มีในระบบได้ 400", async () => {
    const res = await request(app).get("/api/menu?category=xxx");
    expect(res.statusCode).toBe(400);
  });

  it("พนักงานเพิ่มเมนูแล้วลบได้", async () => {
    const created = await request(app)
      .post("/api/menu")
      .set("Authorization", `Bearer ${token}`)
      .send({ name: "ชาไทยทดสอบ", price: 30, category: "เครื่องดื่ม", available: true });
    expect(created.statusCode).toBe(201);
    expect(created.body.name).toBe("ชาไทยทดสอบ");

    const deleted = await request(app)
      .delete(`/api/menu/${created.body.id}`)
      .set("Authorization", `Bearer ${token}`);
    expect(deleted.statusCode).toBe(204);
  });

  it("ลูกค้าเพิ่มเมนูไม่ได้ (401)", async () => {
    const res = await request(app)
      .post("/api/menu")
      .send({ name: "x", price: 1, category: "อาหาร", available: true });
    expect(res.statusCode).toBe(401);
  });
});

describe("ออเดอร์", () => {
  it("สั่งอาหารพร้อมหมายเหตุและโต๊ะ แล้วลูกค้ายกเลิกได้ตอนยังรอรับ", async () => {
    const created = await request(app).post("/api/orders").send({
      customer_name: "ทดสอบ",
      delivery_info: "โต๊ะ 9",
      items: [{ menu_item_id: 1, quantity: 2, note: "ไม่ใส่ผัก" }],
    });
    expect(created.statusCode).toBe(201);
    expect(created.body.status).toBe("pending");
    expect(created.body.delivery_info).toBe("โต๊ะ 9");
    expect(created.body.items[0].note).toBe("ไม่ใส่ผัก");

    const orderId = created.body.id;
    const cancelled = await request(app).post(`/api/orders/${orderId}/cancel`);
    expect(cancelled.statusCode).toBe(200);
    expect(cancelled.body.status).toBe("cancelled");

    // ยกเลิกซ้ำไม่ได้แล้ว
    const again = await request(app).post(`/api/orders/${orderId}/cancel`);
    expect(again.statusCode).toBe(409);

    const removed = await request(app)
      .delete(`/api/orders/${orderId}`)
      .set("Authorization", `Bearer ${token}`);
    expect(removed.statusCode).toBe(204);
  });

  it("พนักงานเปลี่ยนสถานะ แล้วลูกค้ายกเลิกไม่ได้", async () => {
    const created = await request(app).post("/api/orders").send({
      customer_name: "ทดสอบ2",
      items: [{ menu_item_id: 1, quantity: 1 }],
    });
    const orderId = created.body.id;

    const preparing = await request(app)
      .patch(`/api/orders/${orderId}/status`)
      .set("Authorization", `Bearer ${token}`)
      .send({ status: "preparing" });
    expect(preparing.statusCode).toBe(200);

    const cancel = await request(app).post(`/api/orders/${orderId}/cancel`);
    expect(cancel.statusCode).toBe(409);

    // ลูกค้าเปลี่ยนสถานะผ่าน PATCH ไม่ได้ (ต้องเป็นพนักงาน)
    const hack = await request(app)
      .patch(`/api/orders/${orderId}/status`)
      .send({ status: "delivered" });
    expect(hack.statusCode).toBe(401);

    await request(app).patch(`/api/orders/${orderId}/status`)
      .set("Authorization", `Bearer ${token}`).send({ status: "delivered" });
  });

  it("ข้อมูลไม่ถูกต้องได้ 400", async () => {
    const res = await request(app).post("/api/orders").send({
      customer_name: "ทดสอบ3",
      items: [{ menu_item_id: 1, quantity: 1, note: "x".repeat(201) }],
    });
    expect(res.statusCode).toBe(400);
  });
});
