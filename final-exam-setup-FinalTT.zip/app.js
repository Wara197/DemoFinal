// เซิร์ฟเวอร์ Express สำหรับระบบสั่งอาหารออนไลน์ (npm start)
const path = require("path");
const express = require("express");
const { pool } = require("./db");
const { port } = require("./config");

const app = express();

// แปลง body ที่เป็น JSON ให้อยู่ใน req.body
app.use(express.json());

// ให้บริการไฟล์ในโฟลเดอร์ public เช่น index.html ที่หน้าแรก "/"
app.use(express.static(path.join(__dirname, "public")));

// สถานะที่อนุญาตของออเดอร์
const ORDER_STATUSES = ["pending", "preparing", "delivered", "cancelled"];
// สถานะสุดท้าย เปลี่ยนต่อไม่ได้แล้ว
const FINAL_STATUSES = ["delivered", "cancelled"];

// ---------- ฟังก์ชันช่วยเหลือ ----------

// ตรวจว่าเป็นจำนวนเต็มบวก (ใช้กับ id และ quantity)
const isPositiveInt = (value) => Number.isInteger(value) && value > 0;

// แปลงแถวจากฐานข้อมูลให้เป็นรูปแบบที่ส่งให้ผู้ใช้
// mysql2 ส่ง DECIMAL มาเป็น string และ BOOLEAN เป็น 0/1 จึงต้องแปลงก่อน
const toMenuItem = (row) => ({
  id: row.id,
  name: row.name,
  price: Number(row.price),
  available: Boolean(row.available),
});

// ตอบ 500 เมื่อเกิดข้อผิดพลาดกับฐานข้อมูล และบันทึก log ไว้ในเซิร์ฟเวอร์
const sendServerError = (res, err, message) => {
  console.error(message, err.message);
  res.status(500).json({ error: message });
};

// ดึงรายละเอียดออเดอร์ 1 รายการ พร้อมรายการอาหารและยอดรวม
// คืนค่า null ถ้าไม่พบออเดอร์
async function getOrderDetail(orderId) {
  const [orders] = await pool.query(
    "SELECT id, customer_name, status, created_at FROM orders WHERE id = ?",
    [orderId]
  );
  if (orders.length === 0) return null;

  // JOIN กับ menu_items เพื่อเอาชื่อและราคา แล้วคำนวณยอดของแต่ละรายการ
  const [items] = await pool.query(
    `SELECT oi.menu_item_id, m.name, m.price, oi.quantity,
            (m.price * oi.quantity) AS subtotal
       FROM order_items oi
       JOIN menu_items m ON m.id = oi.menu_item_id
      WHERE oi.order_id = ?
      ORDER BY oi.id`,
    [orderId]
  );

  const detailItems = items.map((item) => ({
    menu_item_id: item.menu_item_id,
    name: item.name,
    price: Number(item.price),
    quantity: item.quantity,
    subtotal: Number(item.subtotal),
  }));

  // รวมยอดทั้งออเดอร์ และปัดทศนิยมให้เหลือ 2 ตำแหน่ง
  const total = detailItems.reduce((sum, item) => sum + item.subtotal, 0);

  return {
    id: orders[0].id,
    customer_name: orders[0].customer_name,
    status: orders[0].status,
    created_at: orders[0].created_at,
    items: detailItems,
    total: Math.round(total * 100) / 100,
  };
}

// ---------- Endpoint: เมนู ----------

// GET /api/menu : ดูเมนูทั้งหมด (?available=1 เพื่อดูเฉพาะที่พร้อมขาย)
app.get("/api/menu", async (req, res) => {
  try {
    const onlyAvailable = req.query.available === "1";

    // ใช้ placeholder (?) เพื่อป้องกัน SQL Injection
    const sql = onlyAvailable
      ? "SELECT id, name, price, available FROM menu_items WHERE available = ? ORDER BY id"
      : "SELECT id, name, price, available FROM menu_items ORDER BY id";
    const params = onlyAvailable ? [true] : [];

    const [rows] = await pool.query(sql, params);
    res.json(rows.map(toMenuItem));
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถดึงข้อมูลเมนูได้");
  }
});

// GET /api/menu/:id : ดูเมนู 1 รายการ
app.get("/api/menu/:id", async (req, res) => {
  const id = Number(req.params.id);
  if (!isPositiveInt(id)) {
    return res.status(400).json({ error: "id ต้องเป็นจำนวนเต็มบวก" });
  }

  try {
    const [rows] = await pool.query(
      "SELECT id, name, price, available FROM menu_items WHERE id = ?",
      [id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ error: "ไม่พบเมนูนี้" });
    }
    res.json(toMenuItem(rows[0]));
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถดึงข้อมูลเมนูได้");
  }
});

// PUT /api/menu/:id : แก้ไขเมนู (ต้องส่งครบทั้ง 3 ฟิลด์)
// body: { "name": "ข้าวผัดกุ้ง", "price": 65, "available": true }
app.put("/api/menu/:id", async (req, res) => {
  const id = Number(req.params.id);
  if (!isPositiveInt(id)) {
    return res.status(400).json({ error: "id ต้องเป็นจำนวนเต็มบวก" });
  }

  const { name, price, available } = req.body || {};

  // ตรวจข้อมูลที่รับเข้ามา
  if (typeof name !== "string" || name.trim() === "" || name.trim().length > 200) {
    return res.status(400).json({ error: "name ต้องเป็นข้อความ 1-200 ตัวอักษร" });
  }
  // ราคาเป็นตัวเลข ไม่ติดลบ ไม่เกิน 99999999.99 และทศนิยมไม่เกิน 2 ตำแหน่ง (ตรงกับ DECIMAL(10,2))
  if (
    typeof price !== "number" ||
    !Number.isFinite(price) ||
    price < 0 ||
    price > 99999999.99 ||
    Math.round(price * 100) !== price * 100
  ) {
    return res.status(400).json({ error: "price ต้องเป็นตัวเลขไม่ติดลบ ทศนิยมไม่เกิน 2 ตำแหน่ง" });
  }
  if (typeof available !== "boolean") {
    return res.status(400).json({ error: "available ต้องเป็น true หรือ false" });
  }

  try {
    const [existing] = await pool.query("SELECT id FROM menu_items WHERE id = ?", [id]);
    if (existing.length === 0) return res.status(404).json({ error: "ไม่พบเมนูนี้" });

    await pool.query(
      "UPDATE menu_items SET name = ?, price = ?, available = ? WHERE id = ?",
      [name.trim(), price, available, id]
    );

    const [rows] = await pool.query(
      "SELECT id, name, price, available FROM menu_items WHERE id = ?",
      [id]
    );
    res.json(toMenuItem(rows[0]));
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถแก้ไขเมนูได้");
  }
});

// DELETE /api/menu/:id : ลบเมนู
// ลบไม่ได้ถ้าเมนูนี้เคยถูกสั่งแล้ว (มีในออเดอร์) ให้ใช้ PUT ตั้ง available เป็น false แทน
app.delete("/api/menu/:id", async (req, res) => {
  const id = Number(req.params.id);
  if (!isPositiveInt(id)) {
    return res.status(400).json({ error: "id ต้องเป็นจำนวนเต็มบวก" });
  }

  try {
    const [used] = await pool.query(
      "SELECT COUNT(*) AS total FROM order_items WHERE menu_item_id = ?",
      [id]
    );
    if (used[0].total > 0) {
      return res.status(409).json({
        error: "ลบไม่ได้ เพราะเมนูนี้มีอยู่ในออเดอร์แล้ว ให้แก้เป็นหมดแทน",
      });
    }

    const [result] = await pool.query("DELETE FROM menu_items WHERE id = ?", [id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: "ไม่พบเมนูนี้" });

    // 204 = ลบสำเร็จ ไม่มีเนื้อหาตอบกลับ
    res.status(204).end();
  } catch (err) {
    // ถ้ามีคนสั่งเมนูนี้พร้อมกันจนเกิดการอ้างอิงใหม่ ฐานข้อมูลจะปฏิเสธการลบ
    if (err.code === "ER_ROW_IS_REFERENCED_2") {
      return res.status(409).json({ error: "ลบไม่ได้ เพราะเมนูนี้ถูกใช้งานอยู่" });
    }
    sendServerError(res, err, "ไม่สามารถลบเมนูได้");
  }
});

// ---------- Endpoint: ออเดอร์ ----------

// POST /api/orders : สร้างออเดอร์ใหม่
// รับ body รูปแบบ { "customer_name": "สมชาย", "items": [{ "menu_item_id": 1, "quantity": 2 }] }
app.post("/api/orders", async (req, res) => {
  const { customer_name: customerName, items } = req.body || {};

  // 1) ตรวจข้อมูลที่รับเข้ามา
  if (typeof customerName !== "string" || customerName.trim() === "" || customerName.trim().length > 100) {
    return res.status(400).json({ error: "customer_name ต้องเป็นข้อความ 1-100 ตัวอักษร" });
  }
  if (!Array.isArray(items) || items.length === 0 || items.length > 50) {
    return res.status(400).json({ error: "items ต้องเป็น array ที่มี 1-50 รายการ" });
  }
  for (const item of items) {
    if (!item || !isPositiveInt(item.menu_item_id) || !isPositiveInt(item.quantity) || item.quantity > 99) {
      return res.status(400).json({
        error: "แต่ละรายการต้องมี menu_item_id (จำนวนเต็มบวก) และ quantity (จำนวนเต็ม 1-99)",
      });
    }
  }

  try {
    // 2) ตรวจว่าเมนูทุกรายการมีอยู่จริงและพร้อมขาย
    const menuIds = [...new Set(items.map((item) => item.menu_item_id))];
    const [menuRows] = await pool.query(
      "SELECT id, available FROM menu_items WHERE id IN (?)",
      [menuIds]
    );
    const menuMap = new Map(menuRows.map((row) => [row.id, row]));
    for (const id of menuIds) {
      const menu = menuMap.get(id);
      if (!menu) return res.status(400).json({ error: `ไม่พบเมนู id ${id}` });
      if (!menu.available) return res.status(400).json({ error: `เมนู id ${id} หมดแล้ว` });
    }

    // 3) บันทึกออเดอร์และรายการอาหารในทรานแซกชันเดียวกัน
    // ถ้าขั้นตอนใดล้มเหลว ข้อมูลจะถูกยกเลิกทั้งหมด (rollback) ไม่ให้เหลือออเดอร์ครึ่ง ๆ
    const conn = await pool.getConnection();
    let orderId;
    try {
      await conn.beginTransaction();
      const [orderResult] = await conn.query(
        "INSERT INTO orders (customer_name) VALUES (?)",
        [customerName.trim()]
      );
      orderId = orderResult.insertId;

      // ส่งหลายแถวพร้อมกันด้วย VALUES ? (mysql2 รองรับ array ซ้อน)
      const rows = items.map((item) => [orderId, item.menu_item_id, item.quantity]);
      await conn.query(
        "INSERT INTO order_items (order_id, menu_item_id, quantity) VALUES ?",
        [rows]
      );
      await conn.commit();
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release(); // คืน connection กลับเข้า pool ทุกกรณี
    }

    const order = await getOrderDetail(orderId);
    res.status(201).json(order);
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถสร้างออเดอร์ได้");
  }
});

// GET /api/orders : ดูรายการออเดอร์ทั้งหมด (?status=pending เพื่อกรองตามสถานะ)
app.get("/api/orders", async (req, res) => {
  const { status } = req.query;
  if (status !== undefined && !ORDER_STATUSES.includes(status)) {
    return res.status(400).json({ error: `status ต้องเป็นหนึ่งใน: ${ORDER_STATUSES.join(", ")}` });
  }

  try {
    const sql = status
      ? "SELECT id, customer_name, status, created_at FROM orders WHERE status = ? ORDER BY id DESC"
      : "SELECT id, customer_name, status, created_at FROM orders ORDER BY id DESC";
    const [rows] = await pool.query(sql, status ? [status] : []);
    res.json(rows);
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถดึงรายการออเดอร์ได้");
  }
});

// GET /api/orders/:id : ดูรายละเอียดออเดอร์ 1 รายการ พร้อมยอดรวม
app.get("/api/orders/:id", async (req, res) => {
  const id = Number(req.params.id);
  if (!isPositiveInt(id)) {
    return res.status(400).json({ error: "id ต้องเป็นจำนวนเต็มบวก" });
  }

  try {
    const order = await getOrderDetail(id);
    if (!order) return res.status(404).json({ error: "ไม่พบออเดอร์นี้" });
    res.json(order);
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถดึงข้อมูลออเดอร์ได้");
  }
});

// PATCH /api/orders/:id/status : เปลี่ยนสถานะออเดอร์ เช่น { "status": "preparing" }
app.patch("/api/orders/:id/status", async (req, res) => {
  const id = Number(req.params.id);
  if (!isPositiveInt(id)) {
    return res.status(400).json({ error: "id ต้องเป็นจำนวนเต็มบวก" });
  }

  const { status } = req.body || {};
  if (!ORDER_STATUSES.includes(status)) {
    return res.status(400).json({ error: `status ต้องเป็นหนึ่งใน: ${ORDER_STATUSES.join(", ")}` });
  }

  try {
    const [current] = await pool.query("SELECT status FROM orders WHERE id = ?", [id]);
    if (current.length === 0) return res.status(404).json({ error: "ไม่พบออเดอร์นี้" });

    // ออเดอร์ที่ส่งแล้วหรือยกเลิกแล้ว จะเปลี่ยนสถานะต่อไม่ได้
    if (FINAL_STATUSES.includes(current[0].status)) {
      return res.status(409).json({
        error: `ไม่สามารถเปลี่ยนสถานะได้ เพราะออเดอร์นี้ ${current[0].status} แล้ว`,
      });
    }

    await pool.query("UPDATE orders SET status = ? WHERE id = ?", [status, id]);
    const order = await getOrderDetail(id);
    res.json(order);
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถเปลี่ยนสถานะออเดอร์ได้");
  }
});

// DELETE /api/orders/:id : ลบออเดอร์
// ลบได้เฉพาะออเดอร์ที่ยกเลิก (cancelled) แล้ว รายการอาหารในออเดอร์จะถูกลบตามด้วย (ON DELETE CASCADE)
app.delete("/api/orders/:id", async (req, res) => {
  const id = Number(req.params.id);
  if (!isPositiveInt(id)) {
    return res.status(400).json({ error: "id ต้องเป็นจำนวนเต็มบวก" });
  }

  try {
    const [current] = await pool.query("SELECT status FROM orders WHERE id = ?", [id]);
    if (current.length === 0) return res.status(404).json({ error: "ไม่พบออเดอร์นี้" });

    if (current[0].status !== "cancelled") {
      return res.status(409).json({
        error: `ลบได้เฉพาะออเดอร์ที่ยกเลิกแล้ว ตอนนี้สถานะเป็น ${current[0].status}`,
      });
    }

    await pool.query("DELETE FROM orders WHERE id = ?", [id]);
    res.status(204).end();
  } catch (err) {
    sendServerError(res, err, "ไม่สามารถลบออเดอร์ได้");
  }
});

// ---------- จัดการข้อผิดพลาดทั่วไป ----------

// ถ้าส่ง JSON ที่รูปแบบผิด ให้ตอบ 400 ในรูปแบบ JSON แทนหน้า HTML ของ Express
app.use((err, req, res, next) => {
  if (err.type === "entity.parse.failed") {
    return res.status(400).json({ error: "รูปแบบ JSON ไม่ถูกต้อง" });
  }
  next(err);
});

// เปิดเซิร์ฟเวอร์เฉพาะตอนรันไฟล์นี้โดยตรง (node app.js)
// ถ้า require จากเทสต์ จะไม่เปิดพอร์ตซ้ำ
if (require.main === module) {
  app.listen(port, () => {
    console.log(`เปิดหน้าเว็บที่ http://localhost:${port}`);
  });
}

module.exports = app;
